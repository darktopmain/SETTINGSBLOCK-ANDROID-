package com.example.myapplication

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Handler
import android.view.accessibility.AccessibilityEvent
import androidx.localbroadcastmanager.content.LocalBroadcastManager

class AppBlockerService : AccessibilityService() {

    private var isBlocked = true  // Empieza bloqueado
    private val handler = Handler()

    // BroadcastReceiver para escuchar las solicitudes de desbloqueo
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == "DESBLOQUEAR_SERVICIO") {
                // Desbloquear el servicio
                isBlocked = false
                // Registramos que la app de ajustes está siendo accedida
                handler.postDelayed({
                    isBlocked = true // Vuelve a bloquear después de 30 segundos o cuando el usuario cierre ajustes
                }, 10000) // 30 segundos
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        // Registrar el BroadcastReceiver usando LocalBroadcastManager
        val filter = IntentFilter()
        filter.addAction("DESBLOQUEAR_SERVICIO")
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Detectar si se abre la app de ajustes
        if (event?.packageName == "com.android.settings" && isBlocked) {
            val intent = Intent(this, MainActivity::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }

        // Detectar si se cierra la app de ajustes y volver a bloquear si ha sido desbloqueado
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.packageName != "com.android.settings" && !isBlocked) {
            // Si el usuario cierra los ajustes, vuelve a activar el bloqueo
            isBlocked = true
        }
    }

    override fun onInterrupt() {
        // No se necesita implementar nada aquí
    }

    override fun onDestroy() {
        super.onDestroy()
        // Desregistrar el BroadcastReceiver
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver)
    }
}
