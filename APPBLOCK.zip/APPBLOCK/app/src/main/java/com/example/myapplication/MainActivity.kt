package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.localbroadcastmanager.content.LocalBroadcastManager








class MainActivity : AppCompatActivity() {


    private val correctPassword = "psyrey10smt"  // Cambia esto a tu contraseña

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val passwordEditText = findViewById<EditText>(R.id.passwordEditText)
        val submitButton = findViewById<Button>(R.id.submitButton)
        submitButton.setOnClickListener {
            val enteredPassword = passwordEditText.text.toString()

            if (enteredPassword == correctPassword) {
                // Si la contraseña es correcta, desbloquear el servicio
                val intent = Intent("DESBLOQUEAR_SERVICIO")
                LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
                finish() // Cierra MainActivity después de desbloquear
            } else {
                // Si la contraseña es incorrecta, muestra un mensaje
                Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

